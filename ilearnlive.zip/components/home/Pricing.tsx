'use client'

import { motion } from 'framer-motion'
import { CheckIcon } from '@heroicons/react/24/outline'
import Link from 'next/link'

const plans = [
  {
    name: 'Student',
    price: 'From $15',
    period: '/lesson',
    description: 'Perfect for individual learners',
    features: [
      'Free English level assessment',
      '1-on-1 lessons with certified teachers',
      'Flexible scheduling',
      'Progress tracking',
      'Personal learning library',
      'Mobile app access',
      '24/7 customer support',
    ],
    cta: 'Start Learning',
    href: '/auth/signup?role=student',
    popular: false,
  },
  {
    name: 'Group Classes',
    price: 'From $8',
    period: '/lesson',
    description: 'Learn with others in small groups',
    features: [
      'Small group sessions (max 6 students)',
      'Interactive learning activities',
      'Peer practice opportunities',
      'Reduced cost per lesson',
      'Same quality teachers',
      'Flexible scheduling',
      'Progress tracking',
    ],
    cta: 'Join Group Classes',
    href: '/auth/signup?role=student',
    popular: true,
  },
  {
    name: 'Teacher',
    price: 'Earn up to $35',
    period: '/lesson',
    description: 'Teach English and earn money',
    features: [
      'Set your own rates',
      'Flexible working hours',
      'Global student base',
      'Built-in teaching tools',
      'Payment processing',
      'Student management system',
      'Professional development resources',
    ],
    cta: 'Become a Teacher',
    href: '/auth/signup?role=teacher',
    popular: false,
  },
]

export default function Pricing() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-base text-primary-600 font-semibold tracking-wide uppercase"
          >
            Pricing
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl"
          >
            Choose your learning path
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto"
          >
            Flexible pricing options to fit your budget and learning goals.
          </motion.p>
        </div>

        <div className="mt-10 space-y-4 sm:mt-16 sm:space-y-0 sm:grid sm:grid-cols-3 sm:gap-6 lg:max-w-4xl lg:mx-auto xl:max-w-none xl:mx-0">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className={`relative p-6 bg-white rounded-lg shadow-sm ring-1 ring-gray-200 ${
                plan.popular ? 'ring-2 ring-primary-500' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="inline-flex items-center px-4 py-1 rounded-full text-sm font-medium bg-primary-500 text-white">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="text-center">
                <h3 className="text-lg font-medium text-gray-900">{plan.name}</h3>
                <p className="mt-4 text-sm text-gray-500">{plan.description}</p>
                <p className="mt-4">
                  <span className="text-4xl font-extrabold text-gray-900">{plan.price}</span>
                  <span className="text-base font-medium text-gray-500">{plan.period}</span>
                </p>
              </div>

              <ul className="mt-6 space-y-4">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start">
                    <CheckIcon className="flex-shrink-0 h-5 w-5 text-green-500 mt-0.5" />
                    <span className="ml-3 text-sm text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-8">
                <Link
                  href={plan.href}
                  className={`block w-full text-center px-4 py-2 border border-transparent rounded-md text-sm font-medium transition-colors ${
                    plan.popular
                      ? 'bg-primary-600 text-white hover:bg-primary-700'
                      : 'bg-primary-100 text-primary-700 hover:bg-primary-200'
                  }`}
                >
                  {plan.cta}
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-12 text-center"
        >
          <div className="bg-white rounded-lg shadow-sm p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Need a custom solution?
            </h3>
            <p className="text-lg text-gray-600 mb-6">
              We offer corporate packages and custom learning programs for organizations.
            </p>
            <Link
              href="/contact"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 transition-colors"
            >
              Contact Sales
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
