'use client'

import { motion } from 'framer-motion'
import { 
  UserPlusIcon,
  ClipboardDocumentCheckIcon,
  CalendarDaysIcon,
  VideoCameraIcon
} from '@heroicons/react/24/outline'

const steps = [
  {
    id: 1,
    name: 'Sign Up & Take Assessment',
    description: 'Create your account and complete our free English level assessment to get personalized recommendations.',
    icon: UserPlusIcon,
  },
  {
    id: 2,
    name: 'Choose Your Teacher',
    description: 'Browse our certified teachers, read reviews, and select the perfect match for your learning goals.',
    icon: ClipboardDocumentCheckIcon,
  },
  {
    id: 3,
    name: 'Book Your Lessons',
    description: 'Schedule lessons at times that work for you using our flexible booking system.',
    icon: CalendarDaysIcon,
  },
  {
    id: 4,
    name: 'Start Learning',
    description: 'Join live online classes, access your personal library, and track your progress.',
    icon: VideoCameraIcon,
  },
]

export default function HowItWorks() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-base text-primary-600 font-semibold tracking-wide uppercase"
          >
            How It Works
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl"
          >
            Get started in 4 simple steps
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto"
          >
            Our streamlined process makes it easy to start your English learning journey.
          </motion.p>
        </div>

        <div className="mt-10">
          <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10 lg:grid-cols-4">
            {steps.map((step, index) => (
              <motion.div
                key={step.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className="relative"
              >
                <div className="flex flex-col items-center text-center">
                  <div className="flex items-center justify-center h-16 w-16 rounded-full bg-primary-100 text-primary-600 relative">
                    <step.icon className="h-8 w-8" aria-hidden="true" />
                    <div className="absolute -top-2 -right-2 h-6 w-6 bg-primary-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                      {step.id}
                    </div>
                  </div>
                  <h3 className="mt-4 text-lg font-medium text-gray-900">
                    {step.name}
                  </h3>
                  <p className="mt-2 text-base text-gray-500">
                    {step.description}
                  </p>
                </div>
                
                {/* Connector line */}
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-8 left-1/2 w-full h-0.5 bg-gray-200 transform translate-x-8">
                    <div className="absolute right-0 top-0 w-0 h-0 border-l-4 border-l-gray-200 border-t-2 border-b-2 border-t-transparent border-b-transparent"></div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
