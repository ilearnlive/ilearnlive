# iLearnEnglish Academy

A comprehensive full-stack platform for online English learning, connecting students with certified teachers for personalized live lessons.

## Features

### For Students
- **Free English Level Assessment**: Comprehensive test to determine proficiency level
- **Teacher Discovery**: Browse and select from certified English teachers
- **Flexible Booking**: Schedule lessons at convenient times
- **Live Online Classes**: Zoom-integrated video lessons
- **Progress Tracking**: Monitor improvement with detailed analytics
- **Personal Library**: Access learning materials and notes
- **Mobile Responsive**: Learn on any device

### For Teachers
- **Profile Management**: Create detailed teacher profiles with CV upload
- **Student Management**: Track and manage student progress
- **Earning Potential**: Set competitive hourly rates
- **Teaching Tools**: Built-in resources for effective lessons
- **Flexible Schedule**: Set your own availability

### For Administrators
- **Payment Management**: Monitor transactions and revenue
- **Quality Control**: Review teacher performance and student feedback
- **User Management**: Oversee students, teachers, and platform operations
- **Analytics Dashboard**: Comprehensive platform insights

## Tech Stack

- **Frontend**: Next.js 14, React, TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes, Prisma ORM
- **Database**: PostgreSQL
- **Authentication**: NextAuth.js
- **Payments**: Stripe
- **Video**: Zoom API integration
- **UI Components**: Headless UI, Heroicons
- **Animations**: Framer Motion

## Getting Started

### Prerequisites

- Node.js 18+ 
- PostgreSQL database
- Stripe account (for payments)
- Zoom API credentials (for video calls)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd ilearnenglish-academy
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp env.example .env.local
   ```
   
   Fill in your environment variables:
   ```env
   # Database
   DATABASE_URL="postgresql://username:password@localhost:5432/ilearnenglish_academy"
   
   # NextAuth
   NEXTAUTH_URL="http://localhost:3000"
   NEXTAUTH_SECRET="your-secret-key-here"
   
   # Stripe
   STRIPE_SECRET_KEY="sk_test_..."
   STRIPE_PUBLISHABLE_KEY="pk_test_..."
   
   # Zoom API
   ZOOM_API_KEY="your-zoom-api-key"
   ZOOM_API_SECRET="your-zoom-api-secret"
   ```

4. **Set up the database**
   ```bash
   npx prisma generate
   npx prisma db push
   ```

5. **Run the development server**
   ```bash
   npm run dev
   ```

6. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

## Project Structure

```
├── app/                    # Next.js 14 app directory
│   ├── api/               # API routes
│   ├── auth/              # Authentication pages
│   ├── dashboard/         # Dashboard pages
│   ├── assessment/        # English level test
│   └── page.tsx          # Homepage
├── components/            # React components
│   ├── home/             # Homepage components
│   └── layout/           # Layout components
├── lib/                  # Utility libraries
├── prisma/               # Database schema
├── types/                # TypeScript type definitions
└── public/               # Static assets
```

## Key Features Implementation

### Authentication System
- Role-based access control (Student, Teacher, Admin)
- Secure password hashing with bcrypt
- JWT-based sessions with NextAuth.js

### English Level Assessment
- 10-question adaptive test
- Automatic level determination
- Progress tracking and analytics

### Booking System
- Real-time availability checking
- Calendar integration
- Zoom meeting creation
- Email notifications

### Payment Integration
- Stripe payment processing
- Secure transaction handling
- Refund management
- Revenue tracking

### Video Integration
- Zoom API for live lessons
- Meeting room management
- Recording capabilities
- Screen sharing support

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/signin` - User login
- `GET /api/auth/session` - Get current session

### Assessment
- `POST /api/assessment/save` - Save assessment results

### Bookings
- `GET /api/bookings` - Get user bookings
- `POST /api/bookings` - Create new booking
- `PUT /api/bookings/[id]` - Update booking
- `DELETE /api/bookings/[id]` - Cancel booking

### Payments
- `POST /api/payments/create` - Create payment intent
- `POST /api/payments/confirm` - Confirm payment
- `GET /api/payments` - Get payment history

## Database Schema

The application uses Prisma with PostgreSQL and includes the following main entities:

- **Users**: Students, teachers, and admins
- **Bookings**: Lesson appointments
- **Payments**: Transaction records
- **Reviews**: Student feedback
- **Courses**: Available lesson types
- **Notifications**: System messages
- **Messages**: User communications

## Deployment

### Vercel (Recommended)
1. Connect your GitHub repository to Vercel
2. Set environment variables in Vercel dashboard
3. Deploy automatically on push to main branch

### Other Platforms
- Ensure PostgreSQL database is accessible
- Set all required environment variables
- Run `npm run build` for production build
- Deploy the built application

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@ilearnenglish.academy or create an issue in the repository.

## Roadmap

- [ ] Mobile app development
- [ ] Advanced analytics dashboard
- [ ] AI-powered lesson recommendations
- [ ] Group lesson management
- [ ] Certificate generation
- [ ] Multi-language support
- [ ] Advanced reporting tools
- [ ] Integration with learning management systems
