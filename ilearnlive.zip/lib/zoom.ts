import jwt from 'jsonwebtoken'

interface ZoomMeeting {
  id: string
  join_url: string
  start_url: string
  password?: string
}

export class ZoomAPI {
  private apiKey: string
  private apiSecret: string
  private baseURL = 'https://api.zoom.us/v2'

  constructor() {
    this.apiKey = process.env.ZOOM_API_KEY!
    this.apiSecret = process.env.ZOOM_API_SECRET!
  }

  private generateJWT(): string {
    const payload = {
      iss: this.apiKey,
      exp: Math.floor(Date.now() / 1000) + 60 * 60, // 1 hour
    }

    return jwt.sign(payload, this.apiSecret)
  }

  async createMeeting(
    topic: string,
    startTime: string,
    duration: number,
    teacherEmail: string
  ): Promise<ZoomMeeting> {
    try {
      const token = this.generateJWT()
      
      const response = await fetch(`${this.baseURL}/users/${teacherEmail}/meetings`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          topic,
          type: 2, // Scheduled meeting
          start_time: startTime,
          duration,
          timezone: 'UTC',
          settings: {
            host_video: true,
            participant_video: true,
            join_before_host: false,
            mute_upon_entry: true,
            watermark: true,
            use_pmi: false,
            approval_type: 0, // Automatically approve
            audio: 'both',
            auto_recording: 'cloud',
            enforce_login: false,
            enforce_login_domains: '',
            alternative_hosts: '',
            close_registration: false,
            show_share_button: true,
            allow_multiple_devices: true,
            registrants_confirmation_email: true,
            waiting_room: false,
            request_permission_to_unmute_participants: false,
            global_dial_in_countries: ['US'],
            global_dial_in_numbers: [
              {
                country_name: 'United States',
                country_code: '1',
                number: '+1 646 558 8656',
                type: 'toll',
              },
            ],
          },
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(`Zoom API error: ${error.message}`)
      }

      const meeting = await response.json()

      return {
        id: meeting.id.toString(),
        join_url: meeting.join_url,
        start_url: meeting.start_url,
        password: meeting.password,
      }
    } catch (error) {
      console.error('Error creating Zoom meeting:', error)
      throw error
    }
  }

  async getMeeting(meetingId: string): Promise<ZoomMeeting> {
    try {
      const token = this.generateJWT()
      
      const response = await fetch(`${this.baseURL}/meetings/${meetingId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(`Zoom API error: ${error.message}`)
      }

      const meeting = await response.json()

      return {
        id: meeting.id.toString(),
        join_url: meeting.join_url,
        start_url: meeting.start_url,
        password: meeting.password,
      }
    } catch (error) {
      console.error('Error getting Zoom meeting:', error)
      throw error
    }
  }

  async updateMeeting(
    meetingId: string,
    updates: {
      topic?: string
      start_time?: string
      duration?: number
    }
  ): Promise<void> {
    try {
      const token = this.generateJWT()
      
      const response = await fetch(`${this.baseURL}/meetings/${meetingId}`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(`Zoom API error: ${error.message}`)
      }
    } catch (error) {
      console.error('Error updating Zoom meeting:', error)
      throw error
    }
  }

  async deleteMeeting(meetingId: string): Promise<void> {
    try {
      const token = this.generateJWT()
      
      const response = await fetch(`${this.baseURL}/meetings/${meetingId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(`Zoom API error: ${error.message}`)
      }
    } catch (error) {
      console.error('Error deleting Zoom meeting:', error)
      throw error
    }
  }
}

export const zoomAPI = new ZoomAPI()
