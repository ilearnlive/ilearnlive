import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { zoomAPI } from '@/lib/zoom'
import { z } from 'zod'

const createMeetingSchema = z.object({
  bookingId: z.string().min(1, 'Booking ID is required'),
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { message: 'Unauthorized' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validatedData = createMeetingSchema.parse(body)

    // Get booking details
    const booking = await prisma.booking.findUnique({
      where: {
        id: validatedData.bookingId,
      },
      include: {
        student: true,
        teacher: true,
      },
    })

    if (!booking) {
      return NextResponse.json(
        { message: 'Booking not found' },
        { status: 404 }
      )
    }

    // Check if user has permission to create meeting
    if (session.user.role !== 'ADMIN' && 
        session.user.id !== booking.studentId && 
        session.user.id !== booking.teacherId) {
      return NextResponse.json(
        { message: 'Unauthorized to create meeting for this booking' },
        { status: 403 }
      )
    }

    // Check if meeting already exists
    if (booking.zoomMeetingId) {
      return NextResponse.json(
        { message: 'Meeting already exists for this booking' },
        { status: 400 }
      )
    }

    // Create Zoom meeting
    const meeting = await zoomAPI.createMeeting(
      `English Lesson - ${booking.student.firstName} ${booking.student.lastName}`,
      booking.startTime.toISOString(),
      Math.round((booking.endTime.getTime() - booking.startTime.getTime()) / (1000 * 60)), // duration in minutes
      booking.teacher.email
    )

    // Update booking with Zoom meeting details
    await prisma.booking.update({
      where: {
        id: validatedData.bookingId,
      },
      data: {
        zoomMeetingId: meeting.id,
        zoomJoinUrl: meeting.join_url,
      },
    })

    return NextResponse.json(
      { 
        message: 'Meeting created successfully',
        meetingId: meeting.id,
        joinUrl: meeting.join_url,
        startUrl: meeting.start_url,
        password: meeting.password,
      },
      { status: 201 }
    )
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { message: 'Validation error', errors: error.errors },
        { status: 400 }
      )
    }

    console.error('Meeting creation error:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
