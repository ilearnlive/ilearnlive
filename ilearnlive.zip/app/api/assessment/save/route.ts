import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const assessmentSchema = z.object({
  score: z.number().min(0).max(10),
  totalQuestions: z.number().min(1).max(10),
  level: z.enum(['BEGINNER', 'ELEMENTARY', 'INTERMEDIATE', 'UPPER_INTERMEDIATE', 'ADVANCED']),
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { message: 'Unauthorized' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validatedData = assessmentSchema.parse(body)

    // Update user with assessment results
    await prisma.user.update({
      where: {
        id: session.user.id,
      },
      data: {
        englishLevel: validatedData.level,
        testScore: validatedData.score,
        testCompleted: true,
      },
    })

    return NextResponse.json(
      { message: 'Assessment saved successfully' },
      { status: 200 }
    )
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { message: 'Validation error', errors: error.errors },
        { status: 400 }
      )
    }

    console.error('Assessment save error:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
