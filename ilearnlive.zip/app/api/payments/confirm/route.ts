import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
})

export async function POST(request: NextRequest) {
  try {
    const { paymentIntentId } = await request.json()

    if (!paymentIntentId) {
      return NextResponse.json(
        { message: 'Payment intent ID is required' },
        { status: 400 }
      )
    }

    // Retrieve payment intent from Stripe
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId)

    if (paymentIntent.status !== 'succeeded') {
      return NextResponse.json(
        { message: 'Payment not successful' },
        { status: 400 }
      )
    }

    // Update payment status in database
    const payment = await prisma.payment.update({
      where: {
        stripePaymentId: paymentIntentId,
      },
      data: {
        status: 'COMPLETED',
      },
      include: {
        booking: true,
      },
    })

    if (!payment) {
      return NextResponse.json(
        { message: 'Payment not found' },
        { status: 404 }
      )
    }

    // Update booking status
    await prisma.booking.update({
      where: {
        id: payment.bookingId,
      },
      data: {
        status: 'CONFIRMED',
      },
    })

    // Create Zoom meeting
    try {
      const { zoomAPI } = await import('@/lib/zoom')
      const booking = await prisma.booking.findUnique({
        where: { id: payment.bookingId },
        include: { student: true, teacher: true },
      })

      if (booking) {
        const meeting = await zoomAPI.createMeeting(
          `English Lesson - ${booking.student.firstName} ${booking.student.lastName}`,
          booking.startTime.toISOString(),
          Math.round((booking.endTime.getTime() - booking.startTime.getTime()) / (1000 * 60)),
          booking.teacher.email
        )

        await prisma.booking.update({
          where: { id: payment.bookingId },
          data: {
            zoomMeetingId: meeting.id,
            zoomJoinUrl: meeting.join_url,
          },
        })
      }
    } catch (error) {
      console.error('Error creating Zoom meeting:', error)
      // Don't fail the payment if Zoom meeting creation fails
    }

    // TODO: Send confirmation emails
    // TODO: Create calendar events

    return NextResponse.json(
      { 
        message: 'Payment confirmed successfully',
        bookingId: payment.bookingId,
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Payment confirmation error:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
