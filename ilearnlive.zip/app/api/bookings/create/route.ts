import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const createBookingSchema = z.object({
  teacherId: z.string().min(1, 'Teacher ID is required'),
  startTime: z.string().datetime('Invalid start time'),
  duration: z.number().min(30, 'Duration must be at least 30 minutes').max(180, 'Duration must be at most 180 minutes'),
  type: z.enum(['individual', 'group']),
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { message: 'Unauthorized' },
        { status: 401 }
      )
    }

    if (session.user.role !== 'STUDENT') {
      return NextResponse.json(
        { message: 'Only students can create bookings' },
        { status: 403 }
      )
    }

    const body = await request.json()
    const validatedData = createBookingSchema.parse(body)

    // Check if teacher exists and is verified
    const teacher = await prisma.user.findUnique({
      where: {
        id: validatedData.teacherId,
        role: 'TEACHER',
        status: 'ACTIVE',
      },
      include: {
        teacherProfile: true,
      },
    })

    if (!teacher || !teacher.teacherProfile) {
      return NextResponse.json(
        { message: 'Teacher not found or not verified' },
        { status: 404 }
      )
    }

    const startTime = new Date(validatedData.startTime)
    const endTime = new Date(startTime.getTime() + validatedData.duration * 60000)

    // Check for conflicts
    const conflictingBooking = await prisma.booking.findFirst({
      where: {
        OR: [
          {
            teacherId: validatedData.teacherId,
            startTime: {
              lt: endTime,
            },
            endTime: {
              gt: startTime,
            },
            status: {
              in: ['PENDING', 'CONFIRMED'],
            },
          },
          {
            studentId: session.user.id,
            startTime: {
              lt: endTime,
            },
            endTime: {
              gt: startTime,
            },
            status: {
              in: ['PENDING', 'CONFIRMED'],
            },
          },
        ],
      },
    })

    if (conflictingBooking) {
      return NextResponse.json(
        { message: 'Time slot is not available' },
        { status: 409 }
      )
    }

    // Create booking
    const booking = await prisma.booking.create({
      data: {
        studentId: session.user.id,
        teacherId: validatedData.teacherId,
        startTime,
        endTime,
        status: 'PENDING',
        notes: `Lesson type: ${validatedData.type}`,
      },
    })

    // Create payment record
    const hourlyRate = teacher.teacherProfile.hourlyRate
    const platformFee = 5.00
    const totalAmount = hourlyRate + platformFee

    const payment = await prisma.payment.create({
      data: {
        userId: session.user.id,
        bookingId: booking.id,
        amount: totalAmount,
        currency: 'USD',
        status: 'PENDING',
      },
    })

    // TODO: Create Zoom meeting
    // This would integrate with Zoom API to create a meeting room

    return NextResponse.json(
      { 
        message: 'Booking created successfully',
        bookingId: booking.id,
        paymentId: payment.id,
        totalAmount,
      },
      { status: 201 }
    )
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { message: 'Validation error', errors: error.errors },
        { status: 400 }
      )
    }

    console.error('Booking creation error:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
