'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import {
  UsersIcon,
  CurrencyDollarIcon,
  ChartBarIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  ClockIcon,
  StarIcon,
  UserGroupIcon,
  AcademicCapIcon,
  BellIcon,
  UserIcon,
} from '@heroicons/react/24/outline'

interface AdminStats {
  totalUsers: number
  totalTeachers: number
  totalStudents: number
  monthlyRevenue: number
  pendingApprovals: number
  activeLessons: number
  averageRating: number
  totalBookings: number
}

interface PendingTeacher {
  id: string
  name: string
  email: string
  experience: number
  specialties: string[]
  submittedAt: string
}

interface RecentActivity {
  id: string
  type: string
  description: string
  timestamp: string
  status: 'success' | 'warning' | 'error'
}

export default function AdminDashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 0,
    totalTeachers: 0,
    totalStudents: 0,
    monthlyRevenue: 0,
    pendingApprovals: 0,
    activeLessons: 0,
    averageRating: 0,
    totalBookings: 0,
  })
  const [pendingTeachers, setPendingTeachers] = useState<PendingTeacher[]>([])
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }

    if (status === 'authenticated' && session?.user?.role !== 'ADMIN') {
      router.push('/')
      return
    }

    // Fetch dashboard data
    fetchDashboardData()
  }, [session, status, router])

  const fetchDashboardData = async () => {
    try {
      // In a real app, these would be API calls
      // For now, using mock data
      setStats({
        totalUsers: 1247,
        totalTeachers: 89,
        totalStudents: 1158,
        monthlyRevenue: 45680,
        pendingApprovals: 12,
        activeLessons: 23,
        averageRating: 4.7,
        totalBookings: 342,
      })

      setPendingTeachers([
        {
          id: '1',
          name: 'Sarah Johnson',
          email: 'sarah.johnson@email.com',
          experience: 5,
          specialties: ['Business English', 'IELTS Preparation'],
          submittedAt: '2024-01-10T10:30:00Z',
        },
        {
          id: '2',
          name: 'Michael Chen',
          email: 'michael.chen@email.com',
          experience: 3,
          specialties: ['Conversation Practice', 'Grammar'],
          submittedAt: '2024-01-11T14:20:00Z',
        },
      ])

      setRecentActivity([
        {
          id: '1',
          type: 'payment',
          description: 'Payment received from John Doe - $45.00',
          timestamp: '2024-01-15T09:30:00Z',
          status: 'success',
        },
        {
          id: '2',
          type: 'booking',
          description: 'New lesson booked: Sarah Johnson with Mike Chen',
          timestamp: '2024-01-15T08:45:00Z',
          status: 'success',
        },
        {
          id: '3',
          type: 'teacher',
          description: 'Teacher application pending review: Emma Wilson',
          timestamp: '2024-01-15T07:20:00Z',
          status: 'warning',
        },
        {
          id: '4',
          type: 'system',
          description: 'System maintenance completed successfully',
          timestamp: '2024-01-14T23:00:00Z',
          status: 'success',
        },
      ])
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleTeacherApproval = async (teacherId: string, approved: boolean) => {
    try {
      // In a real app, this would be an API call
      console.log(`Teacher ${teacherId} ${approved ? 'approved' : 'rejected'}`)
      
      // Remove from pending list
      setPendingTeachers(prev => prev.filter(t => t.id !== teacherId))
      
      // Add to recent activity
      setRecentActivity(prev => [{
        id: Date.now().toString(),
        type: 'teacher',
        description: `Teacher ${approved ? 'approved' : 'rejected'}: ${pendingTeachers.find(t => t.id === teacherId)?.name}`,
        timestamp: new Date().toISOString(),
        status: approved ? 'success' : 'error',
      }, ...prev])
    } catch (error) {
      console.error('Error handling teacher approval:', error)
    }
  }

  if (status === 'loading' || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    )
  }

  if (!session || session.user.role !== 'ADMIN') {
    return null
  }

  const quickActions = [
    {
      name: 'Manage Users',
      href: '/dashboard/admin/users',
      icon: UsersIcon,
      color: 'bg-blue-500',
    },
    {
      name: 'Payment Overview',
      href: '/dashboard/admin/payments',
      icon: CurrencyDollarIcon,
      color: 'bg-green-500',
    },
    {
      name: 'Analytics',
      href: '/dashboard/admin/analytics',
      icon: ChartBarIcon,
      color: 'bg-purple-500',
    },
    {
      name: 'System Settings',
      href: '/dashboard/admin/settings',
      icon: ExclamationTriangleIcon,
      color: 'bg-red-500',
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Admin Dashboard
              </h1>
              <p className="text-gray-600">
                Welcome back, {session.user.name?.split(' ')[0]}! Here's your platform overview.
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 text-gray-400 hover:text-gray-500">
                <BellIcon className="h-6 w-6" />
              </button>
              <button className="flex items-center space-x-2 text-gray-700 hover:text-gray-900">
                <UserIcon className="h-6 w-6" />
                <span>Profile</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="bg-white rounded-lg shadow p-6"
          >
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <UsersIcon className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Total Users</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalUsers.toLocaleString()}</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="bg-white rounded-lg shadow p-6"
          >
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <CurrencyDollarIcon className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Monthly Revenue</p>
                <p className="text-2xl font-bold text-gray-900">${stats.monthlyRevenue.toLocaleString()}</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-white rounded-lg shadow p-6"
          >
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <ExclamationTriangleIcon className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Pending Approvals</p>
                <p className="text-2xl font-bold text-gray-900">{stats.pendingApprovals}</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="bg-white rounded-lg shadow p-6"
          >
            <div className="flex items-center">
              <div className="p-2 bg-purple-100 rounded-lg">
                <StarIcon className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Average Rating</p>
                <p className="text-2xl font-bold text-gray-900">{stats.averageRating}</p>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="lg:col-span-1"
          >
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                {quickActions.map((action, index) => (
                  <a
                    key={action.name}
                    href={action.href}
                    className="flex items-center p-3 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className={`p-2 rounded-lg ${action.color}`}>
                      <action.icon className="h-5 w-5 text-white" />
                    </div>
                    <span className="ml-3 text-gray-700">{action.name}</span>
                  </a>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Pending Teacher Approvals */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="lg:col-span-2"
          >
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Pending Teacher Approvals</h3>
              {pendingTeachers.length > 0 ? (
                <div className="space-y-4">
                  {pendingTeachers.map((teacher) => (
                    <div key={teacher.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <AcademicCapIcon className="h-5 w-5 text-blue-600" />
                        </div>
                        <div className="ml-4">
                          <h4 className="font-medium text-gray-900">{teacher.name}</h4>
                          <p className="text-sm text-gray-500">{teacher.email}</p>
                          <p className="text-sm text-gray-500">
                            {teacher.experience} years experience • {teacher.specialties.join(', ')}
                          </p>
                          <p className="text-xs text-gray-400">
                            Applied {new Date(teacher.submittedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleTeacherApproval(teacher.id, true)}
                          className="px-3 py-1 bg-green-600 text-white text-sm rounded-md hover:bg-green-700"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleTeacherApproval(teacher.id, false)}
                          className="px-3 py-1 bg-red-600 text-white text-sm rounded-md hover:bg-red-700"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <CheckCircleIcon className="h-12 w-12 text-green-400 mx-auto mb-4" />
                  <p className="text-gray-500">No pending approvals</p>
                </div>
              )}
            </div>
          </motion.div>
        </div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-8"
        >
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Activity</h3>
            <div className="space-y-4">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center p-4 border border-gray-200 rounded-lg">
                  <div className={`p-2 rounded-lg ${
                    activity.status === 'success' ? 'bg-green-100' :
                    activity.status === 'warning' ? 'bg-yellow-100' : 'bg-red-100'
                  }`}>
                    {activity.status === 'success' && <CheckCircleIcon className="h-5 w-5 text-green-600" />}
                    {activity.status === 'warning' && <ExclamationTriangleIcon className="h-5 w-5 text-yellow-600" />}
                    {activity.status === 'error' && <ExclamationTriangleIcon className="h-5 w-5 text-red-600" />}
                  </div>
                  <div className="ml-4 flex-1">
                    <p className="text-sm text-gray-900">{activity.description}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(activity.timestamp).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
