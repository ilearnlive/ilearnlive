'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import {
  CalendarDaysIcon,
  ClockIcon,
  UserIcon,
  StarIcon,
  AcademicCapIcon,
  VideoCameraIcon,
  CheckCircleIcon,
} from '@heroicons/react/24/outline'
import toast from 'react-hot-toast'
import PaymentForm from '@/components/payment/PaymentForm'

interface Teacher {
  id: string
  name: string
  avatar: string
  specialties: string[]
  rating: number
  totalReviews: number
  hourlyRate: number
  experience: number
  bio: string
  availability: string[]
}

interface TimeSlot {
  time: string
  available: boolean
  teacherId: string
}

export default function BookLesson() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [teachers, setTeachers] = useState<Teacher[]>([])
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null)
  const [selectedDate, setSelectedDate] = useState('')
  const [selectedTime, setSelectedTime] = useState('')
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([])
  const [lessonType, setLessonType] = useState<'individual' | 'group'>('individual')
  const [lessonDuration, setLessonDuration] = useState(60)
  const [isLoading, setIsLoading] = useState(false)
  const [step, setStep] = useState(1)
  const [bookingId, setBookingId] = useState('')
  const [showPayment, setShowPayment] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }

    if (status === 'authenticated' && session?.user?.role !== 'STUDENT') {
      router.push('/')
      return
    }

    fetchTeachers()
  }, [session, status, router])

  const fetchTeachers = async () => {
    try {
      // In a real app, this would be an API call
      const mockTeachers: Teacher[] = [
        {
          id: '1',
          name: 'Sarah Johnson',
          avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80',
          specialties: ['Business English', 'IELTS Preparation', 'Conversation Practice'],
          rating: 4.9,
          totalReviews: 127,
          hourlyRate: 35,
          experience: 8,
          bio: 'Experienced English teacher with 8 years of teaching experience. Specialized in business English and exam preparation.',
          availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
        },
        {
          id: '2',
          name: 'Mike Chen',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80',
          specialties: ['Grammar', 'Pronunciation', 'Kids English'],
          rating: 4.7,
          totalReviews: 89,
          hourlyRate: 25,
          experience: 5,
          bio: 'Passionate about helping students improve their grammar and pronunciation. Great with kids!',
          availability: ['Monday', 'Wednesday', 'Friday', 'Saturday'],
        },
        {
          id: '3',
          name: 'Emma Wilson',
          avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80',
          specialties: ['Academic English', 'Writing Skills', 'TOEFL Preparation'],
          rating: 4.8,
          totalReviews: 156,
          hourlyRate: 40,
          experience: 10,
          bio: 'University professor with extensive experience in academic English and test preparation.',
          availability: ['Tuesday', 'Thursday', 'Saturday', 'Sunday'],
        },
      ]
      setTeachers(mockTeachers)
    } catch (error) {
      console.error('Error fetching teachers:', error)
    }
  }

  const generateTimeSlots = (date: string) => {
    const slots: TimeSlot[] = []
    const startHour = 9
    const endHour = 21
    
    for (let hour = startHour; hour < endHour; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const time = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`
        slots.push({
          time,
          available: Math.random() > 0.3, // Mock availability
          teacherId: selectedTeacher?.id || '',
        })
      }
    }
    
    setTimeSlots(slots)
  }

  const handleTeacherSelect = (teacher: Teacher) => {
    setSelectedTeacher(teacher)
    setStep(2)
  }

  const handleDateSelect = (date: string) => {
    setSelectedDate(date)
    generateTimeSlots(date)
    setStep(3)
  }

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time)
    setStep(4)
  }

  const handleBooking = async () => {
    if (!selectedTeacher || !selectedDate || !selectedTime) {
      toast.error('Please complete all steps')
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch('/api/bookings/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          teacherId: selectedTeacher.id,
          startTime: `${selectedDate}T${selectedTime}:00Z`,
          duration: lessonDuration,
          type: lessonType,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setBookingId(data.bookingId)
        setShowPayment(true)
      } else {
        toast.error(data.message || 'Failed to book lesson')
      }
    } catch (error) {
      toast.error('An error occurred. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const handlePaymentSuccess = () => {
    toast.success('Lesson booked and paid successfully!')
    router.push('/dashboard/student')
  }

  const handlePaymentCancel = () => {
    setShowPayment(false)
    setStep(3)
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    )
  }

  if (!session || session.user.role !== 'STUDENT') {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-6">
            <h1 className="text-2xl font-bold text-gray-900">Book a Lesson</h1>
            <p className="text-gray-600">Find the perfect teacher and schedule your lesson</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-8">
            {[
              { step: 1, title: 'Choose Teacher', icon: UserIcon },
              { step: 2, title: 'Select Date', icon: CalendarDaysIcon },
              { step: 3, title: 'Pick Time', icon: ClockIcon },
              { step: 4, title: 'Confirm', icon: CheckCircleIcon },
            ].map((item, index) => (
              <div key={item.step} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                  step >= item.step ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-500'
                }`}>
                  <item.icon className="h-5 w-5" />
                </div>
                <span className={`ml-2 text-sm font-medium ${
                  step >= item.step ? 'text-primary-600' : 'text-gray-500'
                }`}>
                  {item.title}
                </span>
                {index < 3 && (
                  <div className={`w-16 h-0.5 ml-4 ${
                    step > item.step ? 'bg-primary-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Step 1: Choose Teacher */}
        {step === 1 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Choose Your Teacher</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {teachers.map((teacher) => (
                  <div
                    key={teacher.id}
                    onClick={() => handleTeacherSelect(teacher)}
                    className="bg-white rounded-lg shadow-md p-6 cursor-pointer hover:shadow-lg transition-shadow"
                  >
                    <div className="flex items-center mb-4">
                      <img
                        src={teacher.avatar}
                        alt={teacher.name}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                      <div className="ml-4">
                        <h3 className="text-lg font-semibold text-gray-900">{teacher.name}</h3>
                        <div className="flex items-center">
                          <StarIcon className="h-4 w-4 text-yellow-400" />
                          <span className="ml-1 text-sm text-gray-600">
                            {teacher.rating} ({teacher.totalReviews} reviews)
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-4">{teacher.bio}</p>
                    
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-gray-900 mb-2">Specialties:</h4>
                      <div className="flex flex-wrap gap-1">
                        {teacher.specialties.map((specialty) => (
                          <span
                            key={specialty}
                            className="px-2 py-1 bg-primary-100 text-primary-700 text-xs rounded-full"
                          >
                            {specialty}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-2xl font-bold text-gray-900">${teacher.hourlyRate}</span>
                        <span className="text-sm text-gray-500">/hour</span>
                      </div>
                      <div className="text-sm text-gray-500">
                        {teacher.experience} years exp.
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Step 2: Select Date */}
        {step === 2 && selectedTeacher && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Select Date</h2>
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="grid grid-cols-7 gap-2">
                  {Array.from({ length: 14 }, (_, i) => {
                    const date = new Date()
                    date.setDate(date.getDate() + i)
                    const dateString = date.toISOString().split('T')[0]
                    const isAvailable = selectedTeacher.availability.includes(
                      date.toLocaleDateString('en-US', { weekday: 'long' })
                    )
                    
                    return (
                      <button
                        key={dateString}
                        onClick={() => isAvailable && handleDateSelect(dateString)}
                        disabled={!isAvailable}
                        className={`p-3 text-center rounded-lg border ${
                          isAvailable
                            ? 'border-gray-300 hover:border-primary-500 hover:bg-primary-50'
                            : 'border-gray-200 bg-gray-100 text-gray-400 cursor-not-allowed'
                        }`}
                      >
                        <div className="text-sm font-medium">
                          {date.toLocaleDateString('en-US', { weekday: 'short' })}
                        </div>
                        <div className="text-lg">
                          {date.getDate()}
                        </div>
                      </button>
                    )
                  })}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Step 3: Pick Time */}
        {step === 3 && selectedTeacher && selectedDate && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Pick a Time</h2>
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
                  {timeSlots.map((slot) => (
                    <button
                      key={slot.time}
                      onClick={() => slot.available && handleTimeSelect(slot.time)}
                      disabled={!slot.available}
                      className={`p-3 text-center rounded-lg border ${
                        slot.available
                          ? 'border-gray-300 hover:border-primary-500 hover:bg-primary-50'
                          : 'border-gray-200 bg-gray-100 text-gray-400 cursor-not-allowed'
                      }`}
                    >
                      {slot.time}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Step 4: Confirm Booking */}
        {step === 4 && selectedTeacher && selectedDate && selectedTime && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Confirm Your Booking</h2>
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Lesson Details</h3>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <UserIcon className="h-5 w-5 text-gray-400 mr-3" />
                        <span className="text-gray-900">{selectedTeacher.name}</span>
                      </div>
                      <div className="flex items-center">
                        <CalendarDaysIcon className="h-5 w-5 text-gray-400 mr-3" />
                        <span className="text-gray-900">
                          {new Date(selectedDate).toLocaleDateString('en-US', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                          })}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <ClockIcon className="h-5 w-5 text-gray-400 mr-3" />
                        <span className="text-gray-900">{selectedTime}</span>
                      </div>
                      <div className="flex items-center">
                        <VideoCameraIcon className="h-5 w-5 text-gray-400 mr-3" />
                        <span className="text-gray-900">{lessonDuration} minutes</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Pricing</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Lesson ({lessonDuration} min)</span>
                        <span className="text-gray-900">${selectedTeacher.hourlyRate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Platform fee</span>
                        <span className="text-gray-900">$5.00</span>
                      </div>
                      <div className="border-t pt-2">
                        <div className="flex justify-between text-lg font-semibold">
                          <span>Total</span>
                          <span>${selectedTeacher.hourlyRate + 5}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-end space-x-4">
                  <button
                    onClick={() => setStep(3)}
                    className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleBooking}
                    disabled={isLoading}
                    className="px-6 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isLoading ? 'Booking...' : 'Confirm Booking'}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Payment Form */}
        {showPayment && selectedTeacher && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          >
            <div className="max-w-md w-full">
              <PaymentForm
                bookingId={bookingId}
                amount={selectedTeacher.hourlyRate + 5}
                onSuccess={handlePaymentSuccess}
                onCancel={handlePaymentCancel}
              />
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}
