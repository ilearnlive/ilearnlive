#!/usr/bin/env bash

set -euo pipefail

# iLearnEnglish Academy - Ubuntu 24.04 setup script
# Usage (run as root or with sudo):
#   bash scripts/setup_ubuntu.sh \
#     --domain yourdomain.com \
#     --email admin@yourdomain.com \
#     --repo https://github.com/yourname/ilearnenglish.academy.git \
#     --branch main \
#     --db-name ilearnenglish_academy \
#     --db-user ilearn_user \
#     --db-pass 'StrongPasswordHere' \
#     --nextauth-url https://yourdomain.com \
#     --nextauth-secret 'generate_a_random_secret' \
#     --stripe-pk 'pk_live_xxx' --stripe-sk 'sk_live_xxx' \
#     --paypal-client-id 'live_client_id' --paypal-client-secret 'live_client_secret' \
#     --zoom-key 'zoom_key' --zoom-secret 'zoom_secret'

########################
# Defaults & Arguments  #
########################
APP_NAME="ilearnenglish"
APP_DIR="/var/www/${APP_NAME}"
NODE_VERSION="20"
RUN_USER="$(logname 2>/dev/null || echo ${SUDO_USER:-$USER})"
RUN_HOME="$(eval echo ~${RUN_USER})"
DOMAIN=""
EMAIL=""
REPO=""
BRANCH="main"
DB_NAME="ilearnenglish_academy"
DB_USER="ilearn_user"
DB_PASS=""
NEXTAUTH_URL=""
NEXTAUTH_SECRET=""
STRIPE_PK=""
STRIPE_SK=""
PAYPAL_CLIENT_ID=""
PAYPAL_CLIENT_SECRET=""
ZOOM_KEY=""
ZOOM_SECRET=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --domain) DOMAIN="$2"; shift 2 ;;
    --email) EMAIL="$2"; shift 2 ;;
    --repo) REPO="$2"; shift 2 ;;
    --branch) BRANCH="$2"; shift 2 ;;
    --db-name) DB_NAME="$2"; shift 2 ;;
    --db-user) DB_USER="$2"; shift 2 ;;
    --db-pass) DB_PASS="$2"; shift 2 ;;
    --nextauth-url) NEXTAUTH_URL="$2"; shift 2 ;;
    --nextauth-secret) NEXTAUTH_SECRET="$2"; shift 2 ;;
    --stripe-pk) STRIPE_PK="$2"; shift 2 ;;
    --stripe-sk) STRIPE_SK="$2"; shift 2 ;;
    --paypal-client-id) PAYPAL_CLIENT_ID="$2"; shift 2 ;;
    --paypal-client-secret) PAYPAL_CLIENT_SECRET="$2"; shift 2 ;;
    --zoom-key) ZOOM_KEY="$2"; shift 2 ;;
    --zoom-secret) ZOOM_SECRET="$2"; shift 2 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

if [[ -z "$REPO" ]]; then
  echo "--repo is required (Git URL of this project)"; exit 1
fi

if [[ -z "$DB_PASS" ]]; then
  DB_PASS="$(openssl rand -hex 16)"
  echo "[INFO] Generated random DB password: $DB_PASS"
fi

if [[ -z "$NEXTAUTH_SECRET" ]]; then
  NEXTAUTH_SECRET="$(openssl rand -base64 32 | tr -d '\n')"
  echo "[INFO] Generated random NEXTAUTH_SECRET"
fi

echo "[INFO] Running as user: $RUN_USER"

########################
# System packages       #
########################
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get upgrade -y
apt-get install -y curl ca-certificates gnupg build-essential git unzip \
  nginx ufw postgresql postgresql-contrib \
  software-properties-common

########################
# Node.js & PM2         #
########################
if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
  apt-get install -y nodejs
fi
npm install -g pm2@latest

########################
# PostgreSQL            #
########################
sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" | grep -q 1 || \
  sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';"

sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1 || \
  sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};"

########################
# App directory         #
########################
mkdir -p "$APP_DIR"
chown -R "$RUN_USER":"$RUN_USER" "$APP_DIR"

if [[ ! -d "$APP_DIR/.git" ]]; then
  sudo -u "$RUN_USER" git clone -b "$BRANCH" "$REPO" "$APP_DIR"
else
  pushd "$APP_DIR" >/dev/null
  sudo -u "$RUN_USER" git fetch --all
  sudo -u "$RUN_USER" git checkout "$BRANCH"
  sudo -u "$RUN_USER" git pull --rebase
  popd >/dev/null
fi

########################
# Environment           #
########################
ENV_FILE="$APP_DIR/.env.production"
if [[ ! -f "$ENV_FILE" ]]; then
  sudo -u "$RUN_USER" cp "$APP_DIR/env.example" "$ENV_FILE" || true
fi

cat > "$ENV_FILE" <<EOF
DATABASE_URL="postgresql://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}"

NEXTAUTH_URL="${NEXTAUTH_URL:-http://localhost:3000}"
NEXTAUTH_SECRET="${NEXTAUTH_SECRET}"

STRIPE_SECRET_KEY="${STRIPE_SK}"
STRIPE_PUBLISHABLE_KEY="${STRIPE_PK}"

PAYPAL_CLIENT_ID="${PAYPAL_CLIENT_ID}"
PAYPAL_CLIENT_SECRET="${PAYPAL_CLIENT_SECRET}"

ZOOM_API_KEY="${ZOOM_KEY}"
ZOOM_API_SECRET="${ZOOM_SECRET}"
EOF

chown "$RUN_USER":"$RUN_USER" "$ENV_FILE"
chmod 600 "$ENV_FILE"

########################
# Build & Migrate       #
########################
pushd "$APP_DIR" >/dev/null
sudo -u "$RUN_USER" npm ci || sudo -u "$RUN_USER" npm install
sudo -u "$RUN_USER" npx prisma generate
sudo -u "$RUN_USER" npx prisma migrate deploy || sudo -u "$RUN_USER" npx prisma db push
sudo -u "$RUN_USER" npm run build
popd >/dev/null

########################
# PM2 process           #
########################
sudo -u "$RUN_USER" pm2 delete "$APP_NAME" >/dev/null 2>&1 || true
sudo -u "$RUN_USER" env \
  PATH="/usr/local/bin:/usr/bin:/bin" \
  NODE_ENV=production \
  pm2 start npm --name "$APP_NAME" --cwd "$APP_DIR" -- start
sudo -u "$RUN_USER" pm2 save
pm2 startup systemd -u "$RUN_USER" --hp "$RUN_HOME" >/dev/null 2>&1 || true

########################
# Nginx reverse proxy   #
########################
NGINX_CONF="/etc/nginx/sites-available/${APP_NAME}.conf"
cat > "$NGINX_CONF" <<NGINX
server {
    listen 80;
    server_name ${DOMAIN:-_};

    location / {
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Host \$host;
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
    }

    client_max_body_size 20M;
}
NGINX

ln -sf "$NGINX_CONF" "/etc/nginx/sites-enabled/${APP_NAME}.conf"
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx

########################
# Firewall              #
########################
ufw allow OpenSSH >/dev/null 2>&1 || true
ufw allow 'Nginx Full' >/dev/null 2>&1 || true
yes | ufw enable >/dev/null 2>&1 || true

########################
# SSL (optional)        #
########################
if [[ -n "$DOMAIN" && -n "$EMAIL" ]]; then
  apt-get install -y certbot python3-certbot-nginx
  certbot --nginx --non-interactive --agree-tos -m "$EMAIL" -d "$DOMAIN" || true
fi

echo "\n[SUCCESS] Deployment complete!"
echo "- App dir: $APP_DIR"
echo "- PM2 app: $APP_NAME (pm2 status)"
echo "- URL: ${DOMAIN:-http://<server-ip>}"
echo "- PostgreSQL: db=${DB_NAME}, user=${DB_USER}, pass=${DB_PASS}"
echo "- Env file: $ENV_FILE"


