import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const teacherRegisterSchema = z.object({
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  phone: z.string().optional(),
  country: z.string().optional(),
  bio: z.string().min(50, 'Bio must be at least 50 characters'),
  experience: z.number().min(0, 'Experience must be a positive number'),
  specialties: z.array(z.string()).min(1, 'At least one specialty is required'),
  education: z.string().optional(),
  certifications: z.array(z.string()).optional(),
  hourlyRate: z.number().min(5, 'Hourly rate must be at least $5'),
  availability: z.string().optional(),
  cvUrl: z.string().url('Valid CV URL is required'),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = teacherRegisterSchema.parse(body)

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: {
        email: validatedData.email,
      },
    })

    if (existingUser) {
      return NextResponse.json(
        { message: 'User with this email already exists' },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(validatedData.password, 12)

    // Create user
    const user = await prisma.user.create({
      data: {
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
        email: validatedData.email,
        password: hashedPassword,
        phone: validatedData.phone,
        country: validatedData.country,
        role: 'TEACHER',
        status: 'PENDING', // Teachers need approval
      },
    })

    // Create teacher profile
    await prisma.teacherProfile.create({
      data: {
        userId: user.id,
        bio: validatedData.bio,
        experience: validatedData.experience,
        specialties: validatedData.specialties,
        education: validatedData.education,
        certifications: validatedData.certifications || [],
        hourlyRate: validatedData.hourlyRate,
        availability: validatedData.availability,
        cvUrl: validatedData.cvUrl,
        isVerified: false, // Will be verified by admin
      },
    })

    return NextResponse.json(
      { message: 'Teacher account created successfully. Awaiting approval.', userId: user.id },
      { status: 201 }
    )
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { message: 'Validation error', errors: error.errors },
        { status: 400 }
      )
    }

    console.error('Teacher registration error:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
