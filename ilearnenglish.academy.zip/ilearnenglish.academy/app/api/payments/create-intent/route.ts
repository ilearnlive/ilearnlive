import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { message: 'Unauthorized' },
        { status: 401 }
      )
    }

    const { bookingId } = await request.json()

    if (!bookingId) {
      return NextResponse.json(
        { message: 'Booking ID is required' },
        { status: 400 }
      )
    }

    // Get booking and payment details
    const booking = await prisma.booking.findUnique({
      where: {
        id: bookingId,
        studentId: session.user.id,
      },
      include: {
        payment: true,
        teacher: {
          include: {
            teacherProfile: true,
          },
        },
      },
    })

    if (!booking || !booking.payment) {
      return NextResponse.json(
        { message: 'Booking or payment not found' },
        { status: 404 }
      )
    }

    if (booking.payment.status !== 'PENDING') {
      return NextResponse.json(
        { message: 'Payment already processed' },
        { status: 400 }
      )
    }

    // Create Stripe payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(booking.payment.amount * 100), // Convert to cents
      currency: booking.payment.currency.toLowerCase(),
      metadata: {
        bookingId: booking.id,
        paymentId: booking.payment.id,
        studentId: session.user.id,
        teacherId: booking.teacherId,
      },
      description: `English lesson with ${booking.teacher.firstName} ${booking.teacher.lastName}`,
    })

    // Update payment with Stripe payment intent ID
    await prisma.payment.update({
      where: {
        id: booking.payment.id,
      },
      data: {
        stripePaymentId: paymentIntent.id,
      },
    })

    return NextResponse.json({
      clientSecret: paymentIntent.client_secret,
      paymentId: booking.payment.id,
      publishableKey: process.env.STRIPE_PUBLISHABLE_KEY,
      paypalClientId: process.env.PAYPAL_CLIENT_ID,
    }, { status: 200 })
  } catch (error) {
    console.error('Payment intent creation error:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
