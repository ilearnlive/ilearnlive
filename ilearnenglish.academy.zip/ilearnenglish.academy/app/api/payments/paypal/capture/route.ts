import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

async function getPayPalAccessToken() {
  const auth = Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString('base64')
  const res = await fetch('https://api-m.paypal.com/v1/oauth2/token', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  })
  if (!res.ok) throw new Error('Failed to get PayPal access token')
  return res.json() as Promise<{ access_token: string }>
}

export async function POST(request: NextRequest) {
  try {
    const { orderId, bookingId } = await request.json()
    if (!orderId || !bookingId) {
      return NextResponse.json({ message: 'orderId and bookingId are required' }, { status: 400 })
    }

    const { access_token } = await getPayPalAccessToken()

    const captureRes = await fetch(`https://api-m.paypal.com/v2/checkout/orders/${orderId}/capture`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${access_token}`,
        'Content-Type': 'application/json',
      },
    })
    if (!captureRes.ok) {
      const err = await captureRes.text()
      throw new Error('PayPal capture failed: ' + err)
    }
    const capture = await captureRes.json()

    // Update payment status and booking
    const payment = await prisma.payment.findUnique({ where: { bookingId } })
    if (!payment) {
      return NextResponse.json({ message: 'Payment not found' }, { status: 404 })
    }
    await prisma.payment.update({
      where: { id: payment.id },
      data: { status: 'COMPLETED', stripePaymentId: capture?.purchase_units?.[0]?.payments?.captures?.[0]?.id || null },
    })
    await prisma.booking.update({ where: { id: bookingId }, data: { status: 'CONFIRMED' } })

    return NextResponse.json({ message: 'PayPal payment captured', captureId: capture?.id || null })
  } catch (error) {
    console.error('PayPal capture error:', error)
    return NextResponse.json({ message: 'Internal server error' }, { status: 500 })
  }
}


