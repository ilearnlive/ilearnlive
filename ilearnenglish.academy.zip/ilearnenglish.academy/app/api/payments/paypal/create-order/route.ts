import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

async function getPayPalAccessToken() {
  const auth = Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString('base64')
  const res = await fetch('https://api-m.paypal.com/v1/oauth2/token', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  })
  if (!res.ok) throw new Error('Failed to get PayPal access token')
  return res.json() as Promise<{ access_token: string }>
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ message: 'Unauthorized' }, { status: 401 })
    }

    const { bookingId } = await request.json()
    if (!bookingId) {
      return NextResponse.json({ message: 'Booking ID is required' }, { status: 400 })
    }

    const booking = await prisma.booking.findUnique({
      where: { id: bookingId, studentId: session.user.id },
      include: { payment: true, teacher: true },
    })
    if (!booking || !booking.payment) {
      return NextResponse.json({ message: 'Booking or payment not found' }, { status: 404 })
    }

    if (booking.payment.status !== 'PENDING') {
      return NextResponse.json({ message: 'Payment already processed' }, { status: 400 })
    }

    const { access_token } = await getPayPalAccessToken()

    const orderRes = await fetch('https://api-m.paypal.com/v2/checkout/orders', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        intent: 'CAPTURE',
        purchase_units: [
          {
            amount: {
              currency_code: booking.payment.currency,
              value: booking.payment.amount.toFixed(2),
            },
            description: `English lesson with ${booking.teacher.firstName} ${booking.teacher.lastName}`,
          },
        ],
      }),
    })
    if (!orderRes.ok) {
      const err = await orderRes.text()
      throw new Error('PayPal order creation failed: ' + err)
    }
    const order = await orderRes.json()

    return NextResponse.json({ id: order.id })
  } catch (error) {
    console.error('PayPal create order error:', error)
    return NextResponse.json({ message: 'Internal server error' }, { status: 500 })
  }
}


