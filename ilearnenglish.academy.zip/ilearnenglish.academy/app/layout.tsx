import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from './providers'
import { Toaster } from 'react-hot-toast'
import Link from 'next/link'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'iLearnEnglish Academy - Online English Learning Platform',
  description: 'Connect with certified English teachers for personalized online lessons. Book live classes, track your progress, and master English at your own pace.',
  keywords: 'English learning, online classes, English teachers, language learning, online education',
  authors: [{ name: 'iLearnEnglish Academy' }],
  openGraph: {
    title: 'iLearnEnglish Academy - Online English Learning Platform',
    description: 'Connect with certified English teachers for personalized online lessons.',
    type: 'website',
    locale: 'en_US',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>
          {children}
          <Toaster 
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#363636',
                color: '#fff',
              },
            }}
          />
          <Link
            href={`https://wa.me/212702697370`}
            target="_blank"
            className="fixed bottom-6 right-6 z-50 bg-green-500 hover:bg-green-600 text-white rounded-full shadow-lg px-5 py-3 flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" className="w-5 h-5 fill-current"><path d="M19.11 17.34c-.27-.14-1.6-.79-1.85-.88-.25-.09-.43-.14-.62.14-.18.27-.71.88-.87 1.06-.16.18-.32.2-.59.07-.27-.14-1.13-.42-2.15-1.35-.79-.71-1.33-1.59-1.49-1.86-.16-.27-.02-.41.12-.55.12-.12.27-.32.41-.48.14-.16.18-.27.27-.45.09-.18.05-.34-.02-.48-.07-.14-.62-1.49-.85-2.04-.22-.53-.45-.46-.62-.46-.16 0-.34-.02-.52-.02-.18 0-.48.07-.73.34-.25.27-.96.94-.96 2.29 0 1.35.98 2.65 1.11 2.83.14.18 1.93 2.95 4.67 4.14.65.28 1.16.45 1.56.58.65.2 1.24.17 1.71.1.52-.08 1.6-.65 1.83-1.28.23-.63.23-1.17.16-1.28-.07-.11-.25-.18-.52-.32zM16 3C8.82 3 3 8.82 3 16c0 2.3.62 4.45 1.7 6.3L3 29l6.86-1.8C11.7 28.38 13.78 29 16 29c7.18 0 13-5.82 13-13S23.18 3 16 3zm0 23.71c-2.16 0-4.17-.65-5.85-1.78l-.42-.27-4.1 1.07 1.1-3.99-.28-.41A10.7 10.7 0 0 1 5.29 16c0-5.91 4.8-10.71 10.71-10.71 5.91 0 10.71 4.8 10.71 10.71S21.91 26.71 16 26.71z"/></svg>
            <span className="hidden sm:block">WhatsApp</span>
          </Link>
        </Providers>
      </body>
    </html>
  )
}
