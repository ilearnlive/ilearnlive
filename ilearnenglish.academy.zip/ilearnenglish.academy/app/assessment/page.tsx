'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { CheckCircleIcon, XCircleIcon } from '@heroicons/react/24/outline'
import toast from 'react-hot-toast'

const questions = [
  {
    id: 1,
    question: "What is the correct form of the verb 'to be' in the present tense for 'I'?",
    options: ['am', 'is', 'are', 'be'],
    correct: 0,
    level: 'BEGINNER'
  },
  {
    id: 2,
    question: "Choose the correct sentence:",
    options: [
      'I have been working here since 2020.',
      'I have been work here since 2020.',
      'I am working here since 2020.',
      'I work here since 2020.'
    ],
    correct: 0,
    level: 'INTERMEDIATE'
  },
  {
    id: 3,
    question: "What does 'procrastinate' mean?",
    options: [
      'To work very hard',
      'To delay or postpone something',
      'To celebrate something',
      'To organize something'
    ],
    correct: 1,
    level: 'ADVANCED'
  },
  {
    id: 4,
    question: "Which sentence is grammatically correct?",
    options: [
      'If I would have known, I would have come.',
      'If I had known, I would have come.',
      'If I would know, I would come.',
      'If I know, I will come.'
    ],
    correct: 1,
    level: 'UPPER_INTERMEDIATE'
  },
  {
    id: 5,
    question: "What is the plural of 'child'?",
    options: ['childs', 'children', 'childes', 'child'],
    correct: 1,
    level: 'ELEMENTARY'
  },
  {
    id: 6,
    question: "Choose the correct preposition: 'I'm looking forward ___ your reply.'",
    options: ['to', 'for', 'at', 'in'],
    correct: 0,
    level: 'INTERMEDIATE'
  },
  {
    id: 7,
    question: "What does the idiom 'break the ice' mean?",
    options: [
      'To literally break ice',
      'To start a conversation in a social setting',
      'To end a relationship',
      'To work very hard'
    ],
    correct: 1,
    level: 'ADVANCED'
  },
  {
    id: 8,
    question: "Which sentence uses the passive voice correctly?",
    options: [
      'The book was written by the author.',
      'The author was written the book.',
      'The book written by the author.',
      'The author written the book.'
    ],
    correct: 0,
    level: 'UPPER_INTERMEDIATE'
  },
  {
    id: 9,
    question: "What is the correct form: 'There ___ many people at the party.'",
    options: ['is', 'are', 'was', 'were'],
    correct: 1,
    level: 'ELEMENTARY'
  },
  {
    id: 10,
    question: "Choose the correct conditional sentence:",
    options: [
      'If I will have time, I will call you.',
      'If I have time, I will call you.',
      'If I would have time, I will call you.',
      'If I had time, I will call you.'
    ],
    correct: 1,
    level: 'INTERMEDIATE'
  }
]

const levels = {
  BEGINNER: { min: 0, max: 2, name: 'Beginner', color: 'text-red-600' },
  ELEMENTARY: { min: 3, max: 4, name: 'Elementary', color: 'text-orange-600' },
  INTERMEDIATE: { min: 5, max: 6, name: 'Intermediate', color: 'text-yellow-600' },
  UPPER_INTERMEDIATE: { min: 7, max: 8, name: 'Upper Intermediate', color: 'text-blue-600' },
  ADVANCED: { min: 9, max: 10, name: 'Advanced', color: 'text-green-600' },
}

export default function Assessment() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<number[]>([])
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex)
  }

  const handleNext = () => {
    if (selectedAnswer === null) {
      toast.error('Please select an answer')
      return
    }

    const newAnswers = [...answers, selectedAnswer]
    setAnswers(newAnswers)
    setSelectedAnswer(null)

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      // Test completed
      setShowResult(true)
    }
  }

  const calculateLevel = () => {
    let correctAnswers = 0
    answers.forEach((answer, index) => {
      if (answer === questions[index].correct) {
        correctAnswers++
      }
    })

    // Add current answer if it's the last question
    if (currentQuestion === questions.length - 1 && selectedAnswer !== null) {
      if (selectedAnswer === questions[currentQuestion].correct) {
        correctAnswers++
      }
    }

    for (const [level, range] of Object.entries(levels)) {
      if (correctAnswers >= range.min && correctAnswers <= range.max) {
        return { level, correctAnswers, total: questions.length }
      }
    }

    return { level: 'ADVANCED', correctAnswers, total: questions.length }
  }

  const saveAssessment = async () => {
    setIsLoading(true)
    const result = calculateLevel()

    try {
      const response = await fetch('/api/assessment/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          score: result.correctAnswers,
          totalQuestions: result.total,
          level: result.level,
        }),
      })

      if (response.ok) {
        toast.success('Assessment completed! Redirecting to dashboard...')
        router.push('/dashboard/student')
      } else {
        toast.error('Failed to save assessment')
      }
    } catch (error) {
      toast.error('An error occurred. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  if (showResult) {
    const result = calculateLevel()
    const levelInfo = levels[result.level as keyof typeof levels]

    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="max-w-2xl w-full bg-white rounded-lg shadow-lg p-8"
        >
          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-6">
              <CheckCircleIcon className="h-8 w-8 text-green-600" />
            </div>
            
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Assessment Complete!
            </h2>
            
            <div className="mb-6">
              <p className="text-lg text-gray-600 mb-2">
                You scored <span className="font-bold">{result.correctAnswers}</span> out of <span className="font-bold">{result.total}</span>
              </p>
              <p className={`text-2xl font-bold ${levelInfo.color}`}>
                Your English Level: {levelInfo.name}
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                What this means:
              </h3>
              <p className="text-gray-600 text-left">
                {result.level === 'BEGINNER' && "You're just starting your English learning journey. We'll help you build a strong foundation with basic vocabulary and grammar."}
                {result.level === 'ELEMENTARY' && "You have a basic understanding of English. We'll help you expand your vocabulary and improve your grammar skills."}
                {result.level === 'INTERMEDIATE' && "You have a good foundation in English. We'll help you become more fluent and confident in conversations."}
                {result.level === 'UPPER_INTERMEDIATE' && "You're quite advanced! We'll help you refine your skills and work on more complex language structures."}
                {result.level === 'ADVANCED' && "Excellent! You have a strong command of English. We'll help you perfect your skills and work on nuanced language use."}
              </p>
            </div>

            <button
              onClick={saveAssessment}
              disabled={isLoading}
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="spinner"></div>
              ) : (
                'Continue to Dashboard'
              )}
            </button>
          </div>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-white rounded-lg shadow-lg p-8"
        >
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-gray-900">
                English Level Assessment
              </h2>
              <span className="text-sm text-gray-500">
                Question {currentQuestion + 1} of {questions.length}
              </span>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-primary-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
              ></div>
            </div>
          </div>

          <motion.div
            key={currentQuestion}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h3 className="text-lg font-medium text-gray-900 mb-6">
              {questions[currentQuestion].question}
            </h3>

            <div className="space-y-3">
              {questions[currentQuestion].options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  className={`w-full text-left p-4 rounded-lg border-2 transition-all duration-200 ${
                    selectedAnswer === index
                      ? 'border-primary-500 bg-primary-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <span className="font-medium text-gray-700">
                    {String.fromCharCode(65 + index)}. {option}
                  </span>
                </button>
              ))}
            </div>
          </motion.div>

          <div className="mt-8 flex justify-end">
            <button
              onClick={handleNext}
              disabled={selectedAnswer === null}
              className="px-6 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {currentQuestion === questions.length - 1 ? 'Finish Test' : 'Next Question'}
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
