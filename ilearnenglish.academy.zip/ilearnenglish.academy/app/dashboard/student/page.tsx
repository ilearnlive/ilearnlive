'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import {
  CalendarDaysIcon,
  BookOpenIcon,
  AcademicCapIcon,
  VideoCameraIcon,
  ChartBarIcon,
  BellIcon,
  UserIcon,
  ClockIcon,
  StarIcon,
  CheckCircleIcon,
} from '@heroicons/react/24/outline'
import Link from 'next/link'

interface UpcomingLesson {
  id: string
  title: string
  teacher: string
  startTime: string
  duration: number
  zoomUrl?: string
}

interface RecentLesson {
  id: string
  title: string
  teacher: string
  date: string
  rating?: number
}

interface ProgressStats {
  totalLessons: number
  completedLessons: number
  averageRating: number
  streak: number
}

export default function StudentDashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [upcomingLessons, setUpcomingLessons] = useState<UpcomingLesson[]>([])
  const [recentLessons, setRecentLessons] = useState<RecentLesson[]>([])
  const [progressStats, setProgressStats] = useState<ProgressStats>({
    totalLessons: 0,
    completedLessons: 0,
    averageRating: 0,
    streak: 0,
  })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }

    if (status === 'authenticated' && session?.user?.role !== 'STUDENT') {
      router.push('/')
      return
    }

    // Fetch dashboard data
    fetchDashboardData()
  }, [session, status, router])

  const fetchDashboardData = async () => {
    try {
      // In a real app, these would be API calls
      // For now, using mock data
      setUpcomingLessons([
        {
          id: '1',
          title: 'Conversation Practice',
          teacher: 'Sarah Johnson',
          startTime: '2024-01-15T14:00:00Z',
          duration: 60,
          zoomUrl: 'https://zoom.us/j/123456789',
        },
        {
          id: '2',
          title: 'Grammar Review',
          teacher: 'Mike Chen',
          startTime: '2024-01-17T10:00:00Z',
          duration: 45,
        },
      ])

      setRecentLessons([
        {
          id: '1',
          title: 'Business English',
          teacher: 'Emma Wilson',
          date: '2024-01-10',
          rating: 5,
        },
        {
          id: '2',
          title: 'Pronunciation Practice',
          teacher: 'David Brown',
          date: '2024-01-08',
          rating: 4,
        },
      ])

      setProgressStats({
        totalLessons: 24,
        completedLessons: 20,
        averageRating: 4.8,
        streak: 7,
      })
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  if (status === 'loading' || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    )
  }

  if (!session || session.user.role !== 'STUDENT') {
    return null
  }

  const quickActions = [
    {
      name: 'Book a Lesson',
      href: '/dashboard/student/book',
      icon: CalendarDaysIcon,
      color: 'bg-blue-500',
    },
    {
      name: 'My Library',
      href: '/dashboard/student/library',
      icon: BookOpenIcon,
      color: 'bg-green-500',
    },
    {
      name: 'Find Teachers',
      href: '/teachers',
      icon: AcademicCapIcon,
      color: 'bg-purple-500',
    },
    {
      name: 'Take Assessment',
      href: '/assessment',
      icon: ChartBarIcon,
      color: 'bg-orange-500',
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Welcome back, {session.user.name?.split(' ')[0]}!
              </h1>
              <p className="text-gray-600">
                Ready to continue your English learning journey?
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 text-gray-400 hover:text-gray-500">
                <BellIcon className="h-6 w-6" />
              </button>
              <Link
                href="/dashboard/student/profile"
                className="flex items-center space-x-2 text-gray-700 hover:text-gray-900"
              >
                <UserIcon className="h-6 w-6" />
                <span>Profile</span>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="bg-white rounded-lg shadow p-6"
          >
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <AcademicCapIcon className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Total Lessons</p>
                <p className="text-2xl font-bold text-gray-900">{progressStats.totalLessons}</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="bg-white rounded-lg shadow p-6"
          >
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckCircleIcon className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Completed</p>
                <p className="text-2xl font-bold text-gray-900">{progressStats.completedLessons}</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-white rounded-lg shadow p-6"
          >
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <StarIcon className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Average Rating</p>
                <p className="text-2xl font-bold text-gray-900">{progressStats.averageRating}</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="bg-white rounded-lg shadow p-6"
          >
            <div className="flex items-center">
              <div className="p-2 bg-red-100 rounded-lg">
                <ClockIcon className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Current Streak</p>
                <p className="text-2xl font-bold text-gray-900">{progressStats.streak} days</p>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="lg:col-span-1"
          >
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                {quickActions.map((action, index) => (
                  <Link
                    key={action.name}
                    href={action.href}
                    className="flex items-center p-3 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className={`p-2 rounded-lg ${action.color}`}>
                      <action.icon className="h-5 w-5 text-white" />
                    </div>
                    <span className="ml-3 text-gray-700">{action.name}</span>
                  </Link>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Upcoming Lessons */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="lg:col-span-2"
          >
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Upcoming Lessons</h3>
              {upcomingLessons.length > 0 ? (
                <div className="space-y-4">
                  {upcomingLessons.map((lesson) => (
                    <div key={lesson.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <VideoCameraIcon className="h-5 w-5 text-blue-600" />
                        </div>
                        <div className="ml-4">
                          <h4 className="font-medium text-gray-900">{lesson.title}</h4>
                          <p className="text-sm text-gray-500">with {lesson.teacher}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(lesson.startTime).toLocaleDateString()} at{' '}
                            {new Date(lesson.startTime).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        {lesson.zoomUrl && (
                          <a
                            href={lesson.zoomUrl}
                            className="px-3 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700"
                          >
                            Join
                          </a>
                        )}
                        <button className="px-3 py-1 border border-gray-300 text-gray-700 text-sm rounded-md hover:bg-gray-50">
                          Details
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <CalendarDaysIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No upcoming lessons</p>
                  <Link
                    href="/dashboard/student/book"
                    className="mt-2 inline-block text-primary-600 hover:text-primary-700"
                  >
                    Book a lesson
                  </Link>
                </div>
              )}
            </div>
          </motion.div>
        </div>

        {/* Recent Lessons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-8"
        >
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Lessons</h3>
            {recentLessons.length > 0 ? (
              <div className="space-y-4">
                {recentLessons.map((lesson) => (
                  <div key={lesson.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <BookOpenIcon className="h-5 w-5 text-green-600" />
                      </div>
                      <div className="ml-4">
                        <h4 className="font-medium text-gray-900">{lesson.title}</h4>
                        <p className="text-sm text-gray-500">with {lesson.teacher}</p>
                        <p className="text-sm text-gray-500">{lesson.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      {lesson.rating && (
                        <div className="flex items-center mr-4">
                          <StarIcon className="h-4 w-4 text-yellow-400" />
                          <span className="ml-1 text-sm text-gray-600">{lesson.rating}</span>
                        </div>
                      )}
                      <button className="px-3 py-1 border border-gray-300 text-gray-700 text-sm rounded-md hover:bg-gray-50">
                        Review
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <BookOpenIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No recent lessons</p>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  )
}
