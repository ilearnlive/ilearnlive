'use client'

import { useState, useEffect } from 'react'
import { loadStripe } from '@stripe/stripe-js'
import {
  Elements,
  CardElement,
  useStripe,
  useElements
} from '@stripe/react-stripe-js'
import { PayPalButtons, PayPalScriptProvider } from '@paypal/react-paypal-js'
import { motion } from 'framer-motion'
import { CreditCardIcon, LockClosedIcon } from '@heroicons/react/24/outline'
import toast from 'react-hot-toast'

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

interface PaymentFormProps {
  bookingId: string
  amount: number
  onSuccess: () => void
  onCancel: () => void
}

function PaymentFormComponent({ bookingId, amount, onSuccess, onCancel }: PaymentFormProps) {
  const stripe = useStripe()
  const elements = useElements()
  const [isLoading, setIsLoading] = useState(false)
  const [clientSecret, setClientSecret] = useState('')
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal'>('card')
  const [paypalClientId, setPaypalClientId] = useState('')

  useEffect(() => {
    // Create payment intent
    fetch('/api/payments/create-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ bookingId }),
    })
      .then(res => res.json())
      .then(data => {
        if (data.clientSecret) {
          setClientSecret(data.clientSecret)
          if (data.paypalClientId) setPaypalClientId(data.paypalClientId)
        } else {
          toast.error(data.message || 'Failed to create payment intent')
        }
      })
      .catch(error => {
        console.error('Error creating payment intent:', error)
        toast.error('Failed to create payment intent')
      })
  }, [bookingId])

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()

    if (!stripe || !elements) {
      return
    }

    setIsLoading(true)

    const cardElement = elements.getElement(CardElement)

    if (!cardElement) {
      toast.error('Card element not found')
      setIsLoading(false)
      return
    }

    try {
      const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement,
        },
      })

      if (error) {
        toast.error(error.message || 'Payment failed')
        setIsLoading(false)
        return
      }

      if (paymentIntent.status === 'succeeded') {
        // Confirm payment on server
        const response = await fetch('/api/payments/confirm', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            paymentIntentId: paymentIntent.id,
          }),
        })

        const data = await response.json()

        if (response.ok) {
          toast.success('Payment successful!')
          onSuccess()
        } else {
          toast.error(data.message || 'Payment confirmation failed')
        }
      }
    } catch (error) {
      console.error('Payment error:', error)
      toast.error('Payment failed')
    } finally {
      setIsLoading(false)
    }
  }

  const cardElementOptions = {
    style: {
      base: {
        fontSize: '16px',
        color: '#424770',
        '::placeholder': {
          color: '#aab7c4',
        },
      },
      invalid: {
        color: '#9e2146',
      },
    },
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-lg shadow-lg p-6"
    >
      <div className="flex items-center mb-6">
        <LockClosedIcon className="h-6 w-6 text-green-600 mr-2" />
        <h3 className="text-lg font-semibold text-gray-900">Secure Payment</h3>
      </div>

      <div className="space-y-4 mb-6">
        <label className="block text-sm font-medium text-gray-700">Payment Method</label>
        <div className="flex space-x-2">
          <button
            type="button"
            onClick={() => setPaymentMethod('card')}
            className={`px-3 py-2 rounded-md border ${paymentMethod === 'card' ? 'border-primary-600 text-primary-700 bg-primary-50' : 'border-gray-300 text-gray-700'}`}
          >
            Card (Visa / Mastercard)
          </button>
          <button
            type="button"
            onClick={() => setPaymentMethod('paypal')}
            className={`px-3 py-2 rounded-md border ${paymentMethod === 'paypal' ? 'border-primary-600 text-primary-700 bg-primary-50' : 'border-gray-300 text-gray-700'}`}
          >
            PayPal
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Card Details
          </label>
          <div className="border border-gray-300 rounded-md p-3">
            <CardElement options={cardElementOptions} />
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex justify-between items-center">
            <span className="text-lg font-semibold text-gray-900">Total Amount</span>
            <span className="text-2xl font-bold text-gray-900">${amount.toFixed(2)}</span>
          </div>
          <p className="text-sm text-gray-500 mt-1">
            Your payment is secured by Stripe
          </p>
        </div>

        <div className="flex space-x-4">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={!stripe || !clientSecret || isLoading || paymentMethod !== 'card'}
            className="flex-1 px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isLoading ? (
              <div className="spinner"></div>
            ) : (
              <>
                <CreditCardIcon className="h-5 w-5 mr-2" />
                Pay ${amount.toFixed(2)}
              </>
            )}
          </button>
        </div>
      </form>

      {paymentMethod === 'paypal' && (
        <div className="mt-6">
          <div className="bg-gray-50 rounded-lg p-4 mb-4">
            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold text-gray-900">Total Amount</span>
              <span className="text-2xl font-bold text-gray-900">${amount.toFixed(2)}</span>
            </div>
          </div>
          <PayPalScriptProvider options={{ clientId: paypalClientId || (process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID as string) || '' }}>
            <PayPalButtons
              style={{ layout: 'vertical' }}
              createOrder={async () => {
                const res = await fetch('/api/payments/paypal/create-order', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ bookingId }),
                })
                const data = await res.json()
                if (!res.ok) {
                  toast.error(data.message || 'Failed to create PayPal order')
                  throw new Error('Order creation failed')
                }
                return data.id
              }}
              onApprove={async (data) => {
                const res = await fetch('/api/payments/paypal/capture', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ orderId: data.orderID, bookingId }),
                })
                const out = await res.json()
                if (res.ok) {
                  toast.success('Payment successful!')
                  onSuccess()
                } else {
                  toast.error(out.message || 'Payment capture failed')
                }
              }}
              onCancel={() => {
                toast('Payment cancelled')
              }}
              onError={(err) => {
                console.error(err)
                toast.error('PayPal error')
              }}
            />
            <div className="mt-4">
              <button
                type="button"
                onClick={onCancel}
                className="w-full px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
            </div>
          </PayPalScriptProvider>
        </div>
      )}
    </motion.div>
  )
}

export default function PaymentForm({ bookingId, amount, onSuccess, onCancel }: PaymentFormProps) {
  return (
    <Elements stripe={stripePromise}>
      <PaymentFormComponent
        bookingId={bookingId}
        amount={amount}
        onSuccess={onSuccess}
        onCancel={onCancel}
      />
    </Elements>
  )
}
